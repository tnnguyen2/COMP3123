
import './App.css';
import DataEntryForm from "./components/DataEntryForm"
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div>
      <DataEntryForm />
    </div>
  );
}

export default App;
